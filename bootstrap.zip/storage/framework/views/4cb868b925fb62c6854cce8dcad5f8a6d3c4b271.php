<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header">Certificate Generation Portal</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>



                            <table class="table table-responsive table-borderless">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Name</th>
                                    <th>Registration</th>

                                    <th>School</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $students): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr >
                                        <td style="font-weight:bold"><?php echo e($students->id); ?></td>
                                        <td><?php echo e($students->name); ?></td>
                                        <td><?php echo e($students->regno); ?></td>

                                        <td><?php echo e($students->schname); ?></td>
                                        <td ><a href="<?php echo e(route('data',$students->id)); ?>" style="text-decoration: none;color:blue;font-weight:bold" class="" >Download</a></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        <?php echo e($student->links()); ?>



                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LARAVEL\NOVUSCERTIFICATES\resources\views/home.blade.php ENDPATH**/ ?>